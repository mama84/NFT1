/* eslint-disable no-undef */
<template>
    <section class="item-detail-section section-space">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 pe-xl-5">
                        <div class="item-detail-content">
                            <div class="item-detail-img-container mb-4">
                               
                            </div><!-- end item-detail-img-container -->
                            
                        </div><!-- end item-detail-content -->
                    </div><!-- end col -->
                    <div class="col-lg-6">
                        <div class="item-detail-content mt-4 mt-lg-0">
                            <h1 class="item-detail-title mb-2">{{ title }}</h1>
                            
                        </div><!-- end item-detail-content -->
                    </div><!-- end col -->
                </div><!-- end row -->
            </div><!-- .container -->

        </section><!-- end item-detail-section -->
</template>

<script>
export default {
  name: 'ProductDetailSection',
  
}
</script>
