//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js');

// Bootstrap
@@include('@@nodeRoot/node_modules/bootstrap/dist/js/bootstrap.min.js');

/*! Swiper */
@@include('@@nodeRoot/node_modules/swiper/swiper-bundle.min.js');

/*! Clipboard */
@@include('@@nodeRoot/node_modules/clipboard/dist/clipboard.min.js');

/*! intl-tel-input */
@@include('@@nodeRoot/node_modules/intl-tel-input/build/js/intlTelInput.min.js');
@@include('@@nodeRoot/node_modules/intl-tel-input/build/js/utils.js');

/*! isotope  */
@@include('@@nodeRoot/node_modules/isotope-layout/dist/isotope.pkgd.min.js');

/*! choices select js  */
@@include('@@nodeRoot/node_modules/choices.js/public/assets/scripts/choices.min.js');

/*! Animation Functions */
@@include('vendors/functions.min.js');
